﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtnamaBarang = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtManu = New System.Windows.Forms.TextBox()
        Me.txtExpire = New System.Windows.Forms.TextBox()
        Me.txtJumlah = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.lvDisplay = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(32, 52)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nama Barang"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(32, 86)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Manufacturer"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(32, 124)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Jumlah"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(32, 164)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(62, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Expire Date"
        '
        'txtnamaBarang
        '
        Me.txtnamaBarang.Location = New System.Drawing.Point(155, 52)
        Me.txtnamaBarang.Name = "txtnamaBarang"
        Me.txtnamaBarang.Size = New System.Drawing.Size(143, 20)
        Me.txtnamaBarang.TabIndex = 4
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(385, 9)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 13)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Unit 2"
        '
        'txtManu
        '
        Me.txtManu.Location = New System.Drawing.Point(155, 83)
        Me.txtManu.Name = "txtManu"
        Me.txtManu.Size = New System.Drawing.Size(143, 20)
        Me.txtManu.TabIndex = 6
        '
        'txtExpire
        '
        Me.txtExpire.Location = New System.Drawing.Point(155, 164)
        Me.txtExpire.Name = "txtExpire"
        Me.txtExpire.Size = New System.Drawing.Size(143, 20)
        Me.txtExpire.TabIndex = 7
        '
        'txtJumlah
        '
        Me.txtJumlah.Location = New System.Drawing.Point(155, 121)
        Me.txtJumlah.Name = "txtJumlah"
        Me.txtJumlah.Size = New System.Drawing.Size(143, 20)
        Me.txtJumlah.TabIndex = 8
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(155, 205)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 9
        Me.Button1.Text = "New"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'lvDisplay
        '
        Me.lvDisplay.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4})
        Me.lvDisplay.FullRowSelect = True
        Me.lvDisplay.GridLines = True
        Me.lvDisplay.Location = New System.Drawing.Point(50, 271)
        Me.lvDisplay.Name = "lvDisplay"
        Me.lvDisplay.Size = New System.Drawing.Size(619, 151)
        Me.lvDisplay.TabIndex = 10
        Me.lvDisplay.UseCompatibleStateImageBehavior = False
        Me.lvDisplay.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Nama Barang"
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Jumlah"
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Manufakturer"
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "Expiry Date"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lvDisplay)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtJumlah)
        Me.Controls.Add(Me.txtExpire)
        Me.Controls.Add(Me.txtManu)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtnamaBarang)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtnamaBarang As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtManu As TextBox
    Friend WithEvents txtExpire As TextBox
    Friend WithEvents txtJumlah As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents lvDisplay As ListView
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents ColumnHeader3 As ColumnHeader
    Friend WithEvents ColumnHeader4 As ColumnHeader
End Class
