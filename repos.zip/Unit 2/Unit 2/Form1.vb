﻿Public Class Form1

    Dim namaBarang As String
    Dim jumlah As String
    Dim manu As String
    Dim expir As String
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        namaBarang = txtnamaBarang.Text
        jumlah = txtJumlah.Text
        manu = txtManu.Text
        expir = txtExpire.Text
        lvDisplay.Items.Add(New ListViewItem(New String() {namaBarang, jumlah, manu, expir}))
    End Sub
End Class
