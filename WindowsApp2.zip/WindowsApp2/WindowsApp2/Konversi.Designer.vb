﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Konversi
    Inherits MaterialSkin.Controls.MaterialForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.MaterialFlatButton1 = New MaterialSkin.Controls.MaterialFlatButton()
        Me.MaterialLabel1 = New MaterialSkin.Controls.MaterialLabel()
        Me.MaterialRadioButton5 = New MaterialSkin.Controls.MaterialRadioButton()
        Me.MaterialRadioButton6 = New MaterialSkin.Controls.MaterialRadioButton()
        Me.MaterialRadioButton7 = New MaterialSkin.Controls.MaterialRadioButton()
        Me.MaterialDivider2 = New MaterialSkin.Controls.MaterialDivider()
        Me.MaterialRadioButton8 = New MaterialSkin.Controls.MaterialRadioButton()
        Me.tjumlah = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.MaterialLabel2 = New MaterialSkin.Controls.MaterialLabel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.MaterialLabel3 = New MaterialSkin.Controls.MaterialLabel()
        Me.MaterialLabel4 = New MaterialSkin.Controls.MaterialLabel()
        Me.MaterialLabel5 = New MaterialSkin.Controls.MaterialLabel()
        Me.MaterialLabel6 = New MaterialSkin.Controls.MaterialLabel()
        Me.MaterialLabel7 = New MaterialSkin.Controls.MaterialLabel()
        Me.MaterialLabel8 = New MaterialSkin.Controls.MaterialLabel()
        Me.kursIDR = New MaterialSkin.Controls.MaterialLabel()
        Me.kursUSD = New MaterialSkin.Controls.MaterialLabel()
        Me.kursGBP = New MaterialSkin.Controls.MaterialLabel()
        Me.kursEUR = New MaterialSkin.Controls.MaterialLabel()
        Me.kursEUR2 = New MaterialSkin.Controls.MaterialLabel()
        Me.kursGBP2 = New MaterialSkin.Controls.MaterialLabel()
        Me.kursUSD2 = New MaterialSkin.Controls.MaterialLabel()
        Me.kursIDR2 = New MaterialSkin.Controls.MaterialLabel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tduit2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.tidrawal = New System.Windows.Forms.Label()
        Me.takhir = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MaterialFlatButton1
        '
        Me.MaterialFlatButton1.AutoSize = True
        Me.MaterialFlatButton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.MaterialFlatButton1.Depth = 0
        Me.MaterialFlatButton1.Location = New System.Drawing.Point(207, 235)
        Me.MaterialFlatButton1.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.MaterialFlatButton1.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialFlatButton1.Name = "MaterialFlatButton1"
        Me.MaterialFlatButton1.Primary = False
        Me.MaterialFlatButton1.Size = New System.Drawing.Size(77, 36)
        Me.MaterialFlatButton1.TabIndex = 0
        Me.MaterialFlatButton1.Text = "Konversi"
        Me.MaterialFlatButton1.UseVisualStyleBackColor = True
        '
        'MaterialLabel1
        '
        Me.MaterialLabel1.AutoSize = True
        Me.MaterialLabel1.Depth = 0
        Me.MaterialLabel1.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.MaterialLabel1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.MaterialLabel1.Location = New System.Drawing.Point(133, 154)
        Me.MaterialLabel1.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialLabel1.Name = "MaterialLabel1"
        Me.MaterialLabel1.Size = New System.Drawing.Size(27, 19)
        Me.MaterialLabel1.TabIndex = 6
        Me.MaterialLabel1.Text = "KE"
        '
        'MaterialRadioButton5
        '
        Me.MaterialRadioButton5.AutoSize = True
        Me.MaterialRadioButton5.Depth = 0
        Me.MaterialRadioButton5.Font = New System.Drawing.Font("Roboto", 10.0!)
        Me.MaterialRadioButton5.Location = New System.Drawing.Point(21, 108)
        Me.MaterialRadioButton5.Margin = New System.Windows.Forms.Padding(0)
        Me.MaterialRadioButton5.MouseLocation = New System.Drawing.Point(-1, -1)
        Me.MaterialRadioButton5.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialRadioButton5.Name = "MaterialRadioButton5"
        Me.MaterialRadioButton5.Ripple = True
        Me.MaterialRadioButton5.Size = New System.Drawing.Size(54, 30)
        Me.MaterialRadioButton5.TabIndex = 11
        Me.MaterialRadioButton5.TabStop = True
        Me.MaterialRadioButton5.Text = "EUR"
        Me.MaterialRadioButton5.UseVisualStyleBackColor = True
        '
        'MaterialRadioButton6
        '
        Me.MaterialRadioButton6.AutoSize = True
        Me.MaterialRadioButton6.Depth = 0
        Me.MaterialRadioButton6.Font = New System.Drawing.Font("Roboto", 10.0!)
        Me.MaterialRadioButton6.Location = New System.Drawing.Point(20, 78)
        Me.MaterialRadioButton6.Margin = New System.Windows.Forms.Padding(0)
        Me.MaterialRadioButton6.MouseLocation = New System.Drawing.Point(-1, -1)
        Me.MaterialRadioButton6.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialRadioButton6.Name = "MaterialRadioButton6"
        Me.MaterialRadioButton6.Ripple = True
        Me.MaterialRadioButton6.Size = New System.Drawing.Size(56, 30)
        Me.MaterialRadioButton6.TabIndex = 10
        Me.MaterialRadioButton6.TabStop = True
        Me.MaterialRadioButton6.Text = "GBP"
        Me.MaterialRadioButton6.UseVisualStyleBackColor = True
        '
        'MaterialRadioButton7
        '
        Me.MaterialRadioButton7.AutoSize = True
        Me.MaterialRadioButton7.Depth = 0
        Me.MaterialRadioButton7.Font = New System.Drawing.Font("Roboto", 10.0!)
        Me.MaterialRadioButton7.Location = New System.Drawing.Point(20, 48)
        Me.MaterialRadioButton7.Margin = New System.Windows.Forms.Padding(0)
        Me.MaterialRadioButton7.MouseLocation = New System.Drawing.Point(-1, -1)
        Me.MaterialRadioButton7.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialRadioButton7.Name = "MaterialRadioButton7"
        Me.MaterialRadioButton7.Ripple = True
        Me.MaterialRadioButton7.Size = New System.Drawing.Size(55, 30)
        Me.MaterialRadioButton7.TabIndex = 9
        Me.MaterialRadioButton7.TabStop = True
        Me.MaterialRadioButton7.Text = "USD"
        Me.MaterialRadioButton7.UseVisualStyleBackColor = True
        '
        'MaterialDivider2
        '
        Me.MaterialDivider2.BackColor = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.MaterialDivider2.Depth = 0
        Me.MaterialDivider2.Location = New System.Drawing.Point(88, 18)
        Me.MaterialDivider2.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialDivider2.Name = "MaterialDivider2"
        Me.MaterialDivider2.Size = New System.Drawing.Size(10, 121)
        Me.MaterialDivider2.TabIndex = 8
        Me.MaterialDivider2.Text = "MaterialDivider2"
        '
        'MaterialRadioButton8
        '
        Me.MaterialRadioButton8.AutoSize = True
        Me.MaterialRadioButton8.Depth = 0
        Me.MaterialRadioButton8.Font = New System.Drawing.Font("Roboto", 10.0!)
        Me.MaterialRadioButton8.Location = New System.Drawing.Point(21, 18)
        Me.MaterialRadioButton8.Margin = New System.Windows.Forms.Padding(0)
        Me.MaterialRadioButton8.MouseLocation = New System.Drawing.Point(-1, -1)
        Me.MaterialRadioButton8.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialRadioButton8.Name = "MaterialRadioButton8"
        Me.MaterialRadioButton8.Ripple = True
        Me.MaterialRadioButton8.Size = New System.Drawing.Size(50, 30)
        Me.MaterialRadioButton8.TabIndex = 7
        Me.MaterialRadioButton8.TabStop = True
        Me.MaterialRadioButton8.Text = "IDR"
        Me.MaterialRadioButton8.UseVisualStyleBackColor = True
        '
        'tjumlah
        '
        Me.tjumlah.Depth = 0
        Me.tjumlah.Hint = "Masukkan jumlah uang"
        Me.tjumlah.Location = New System.Drawing.Point(15, 235)
        Me.tjumlah.MouseState = MaterialSkin.MouseState.HOVER
        Me.tjumlah.Name = "tjumlah"
        Me.tjumlah.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.tjumlah.SelectedText = ""
        Me.tjumlah.SelectionLength = 0
        Me.tjumlah.SelectionStart = 0
        Me.tjumlah.Size = New System.Drawing.Size(167, 23)
        Me.tjumlah.TabIndex = 12
        Me.tjumlah.UseSystemPasswordChar = False
        '
        'MaterialLabel2
        '
        Me.MaterialLabel2.AutoSize = True
        Me.MaterialLabel2.Depth = 0
        Me.MaterialLabel2.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.MaterialLabel2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.MaterialLabel2.Location = New System.Drawing.Point(379, 99)
        Me.MaterialLabel2.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialLabel2.Name = "MaterialLabel2"
        Me.MaterialLabel2.Size = New System.Drawing.Size(92, 19)
        Me.MaterialLabel2.TabIndex = 13
        Me.MaterialLabel2.Text = "Kurs hari ini:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.MaterialRadioButton5)
        Me.GroupBox1.Controls.Add(Me.MaterialRadioButton6)
        Me.GroupBox1.Controls.Add(Me.MaterialRadioButton7)
        Me.GroupBox1.Controls.Add(Me.MaterialDivider2)
        Me.GroupBox1.Controls.Add(Me.MaterialRadioButton8)
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox1.Location = New System.Drawing.Point(186, 76)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(117, 149)
        Me.GroupBox1.TabIndex = 14
        Me.GroupBox1.TabStop = False
        '
        'MaterialLabel3
        '
        Me.MaterialLabel3.AutoSize = True
        Me.MaterialLabel3.Depth = 0
        Me.MaterialLabel3.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.MaterialLabel3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.MaterialLabel3.Location = New System.Drawing.Point(379, 135)
        Me.MaterialLabel3.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialLabel3.Name = "MaterialLabel3"
        Me.MaterialLabel3.Size = New System.Drawing.Size(32, 19)
        Me.MaterialLabel3.TabIndex = 15
        Me.MaterialLabel3.Text = "IDR"
        '
        'MaterialLabel4
        '
        Me.MaterialLabel4.AutoSize = True
        Me.MaterialLabel4.Depth = 0
        Me.MaterialLabel4.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.MaterialLabel4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.MaterialLabel4.Location = New System.Drawing.Point(379, 184)
        Me.MaterialLabel4.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialLabel4.Name = "MaterialLabel4"
        Me.MaterialLabel4.Size = New System.Drawing.Size(37, 19)
        Me.MaterialLabel4.TabIndex = 16
        Me.MaterialLabel4.Text = "GBP"
        '
        'MaterialLabel5
        '
        Me.MaterialLabel5.AutoSize = True
        Me.MaterialLabel5.Depth = 0
        Me.MaterialLabel5.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.MaterialLabel5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.MaterialLabel5.Location = New System.Drawing.Point(379, 159)
        Me.MaterialLabel5.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialLabel5.Name = "MaterialLabel5"
        Me.MaterialLabel5.Size = New System.Drawing.Size(38, 19)
        Me.MaterialLabel5.TabIndex = 17
        Me.MaterialLabel5.Text = "USD"
        '
        'MaterialLabel6
        '
        Me.MaterialLabel6.AutoSize = True
        Me.MaterialLabel6.Depth = 0
        Me.MaterialLabel6.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.MaterialLabel6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.MaterialLabel6.Location = New System.Drawing.Point(379, 206)
        Me.MaterialLabel6.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialLabel6.Name = "MaterialLabel6"
        Me.MaterialLabel6.Size = New System.Drawing.Size(37, 19)
        Me.MaterialLabel6.TabIndex = 18
        Me.MaterialLabel6.Text = "EUR"
        '
        'MaterialLabel7
        '
        Me.MaterialLabel7.AutoSize = True
        Me.MaterialLabel7.Depth = 0
        Me.MaterialLabel7.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.MaterialLabel7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.MaterialLabel7.Location = New System.Drawing.Point(457, 118)
        Me.MaterialLabel7.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialLabel7.Name = "MaterialLabel7"
        Me.MaterialLabel7.Size = New System.Drawing.Size(37, 19)
        Me.MaterialLabel7.TabIndex = 19
        Me.MaterialLabel7.Text = "Jual"
        '
        'MaterialLabel8
        '
        Me.MaterialLabel8.AutoSize = True
        Me.MaterialLabel8.Depth = 0
        Me.MaterialLabel8.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.MaterialLabel8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.MaterialLabel8.Location = New System.Drawing.Point(591, 118)
        Me.MaterialLabel8.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialLabel8.Name = "MaterialLabel8"
        Me.MaterialLabel8.Size = New System.Drawing.Size(34, 19)
        Me.MaterialLabel8.TabIndex = 20
        Me.MaterialLabel8.Text = "Beli"
        '
        'kursIDR
        '
        Me.kursIDR.AutoSize = True
        Me.kursIDR.Depth = 0
        Me.kursIDR.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.kursIDR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.kursIDR.Location = New System.Drawing.Point(439, 137)
        Me.kursIDR.MouseState = MaterialSkin.MouseState.HOVER
        Me.kursIDR.Name = "kursIDR"
        Me.kursIDR.Size = New System.Drawing.Size(108, 19)
        Me.kursIDR.TabIndex = 21
        Me.kursIDR.Text = "MaterialLabel9"
        '
        'kursUSD
        '
        Me.kursUSD.AutoSize = True
        Me.kursUSD.Depth = 0
        Me.kursUSD.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.kursUSD.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.kursUSD.Location = New System.Drawing.Point(439, 159)
        Me.kursUSD.MouseState = MaterialSkin.MouseState.HOVER
        Me.kursUSD.Name = "kursUSD"
        Me.kursUSD.Size = New System.Drawing.Size(116, 19)
        Me.kursUSD.TabIndex = 22
        Me.kursUSD.Text = "MaterialLabel10"
        '
        'kursGBP
        '
        Me.kursGBP.AutoSize = True
        Me.kursGBP.Depth = 0
        Me.kursGBP.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.kursGBP.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.kursGBP.Location = New System.Drawing.Point(439, 184)
        Me.kursGBP.MouseState = MaterialSkin.MouseState.HOVER
        Me.kursGBP.Name = "kursGBP"
        Me.kursGBP.Size = New System.Drawing.Size(116, 19)
        Me.kursGBP.TabIndex = 23
        Me.kursGBP.Text = "MaterialLabel11"
        '
        'kursEUR
        '
        Me.kursEUR.AutoSize = True
        Me.kursEUR.Depth = 0
        Me.kursEUR.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.kursEUR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.kursEUR.Location = New System.Drawing.Point(439, 206)
        Me.kursEUR.MouseState = MaterialSkin.MouseState.HOVER
        Me.kursEUR.Name = "kursEUR"
        Me.kursEUR.Size = New System.Drawing.Size(116, 19)
        Me.kursEUR.TabIndex = 24
        Me.kursEUR.Text = "MaterialLabel12"
        '
        'kursEUR2
        '
        Me.kursEUR2.AutoSize = True
        Me.kursEUR2.Depth = 0
        Me.kursEUR2.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.kursEUR2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.kursEUR2.Location = New System.Drawing.Point(576, 206)
        Me.kursEUR2.MouseState = MaterialSkin.MouseState.HOVER
        Me.kursEUR2.Name = "kursEUR2"
        Me.kursEUR2.Size = New System.Drawing.Size(116, 19)
        Me.kursEUR2.TabIndex = 28
        Me.kursEUR2.Text = "MaterialLabel12"
        '
        'kursGBP2
        '
        Me.kursGBP2.AutoSize = True
        Me.kursGBP2.Depth = 0
        Me.kursGBP2.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.kursGBP2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.kursGBP2.Location = New System.Drawing.Point(576, 184)
        Me.kursGBP2.MouseState = MaterialSkin.MouseState.HOVER
        Me.kursGBP2.Name = "kursGBP2"
        Me.kursGBP2.Size = New System.Drawing.Size(116, 19)
        Me.kursGBP2.TabIndex = 27
        Me.kursGBP2.Text = "MaterialLabel11"
        '
        'kursUSD2
        '
        Me.kursUSD2.AutoSize = True
        Me.kursUSD2.Depth = 0
        Me.kursUSD2.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.kursUSD2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.kursUSD2.Location = New System.Drawing.Point(576, 159)
        Me.kursUSD2.MouseState = MaterialSkin.MouseState.HOVER
        Me.kursUSD2.Name = "kursUSD2"
        Me.kursUSD2.Size = New System.Drawing.Size(116, 19)
        Me.kursUSD2.TabIndex = 26
        Me.kursUSD2.Text = "MaterialLabel10"
        '
        'kursIDR2
        '
        Me.kursIDR2.AutoSize = True
        Me.kursIDR2.Depth = 0
        Me.kursIDR2.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.kursIDR2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.kursIDR2.Location = New System.Drawing.Point(576, 137)
        Me.kursIDR2.MouseState = MaterialSkin.MouseState.HOVER
        Me.kursIDR2.Name = "kursIDR2"
        Me.kursIDR2.Size = New System.Drawing.Size(108, 19)
        Me.kursIDR2.TabIndex = 25
        Me.kursIDR2.Text = "MaterialLabel9"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Aqua Grotesque", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(18, 135)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(109, 61)
        Me.Label1.TabIndex = 29
        Me.Label1.Text = "IDR"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Aqua Grotesque", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(208, 291)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(109, 61)
        Me.Label2.TabIndex = 30
        Me.Label2.Text = "IDR"
        '
        'tduit2
        '
        Me.tduit2.AutoSize = True
        Me.tduit2.Font = New System.Drawing.Font("Aqua Grotesque", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tduit2.Location = New System.Drawing.Point(385, 291)
        Me.tduit2.Name = "tduit2"
        Me.tduit2.Size = New System.Drawing.Size(109, 61)
        Me.tduit2.TabIndex = 31
        Me.tduit2.Text = "IDR"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Aqua Grotesque", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(312, 291)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(70, 61)
        Me.Label4.TabIndex = 32
        Me.Label4.Text = "->"
        '
        'tidrawal
        '
        Me.tidrawal.AutoSize = True
        Me.tidrawal.Font = New System.Drawing.Font("Aqua Grotesque", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tidrawal.Location = New System.Drawing.Point(108, 368)
        Me.tidrawal.Name = "tidrawal"
        Me.tidrawal.Size = New System.Drawing.Size(109, 61)
        Me.tidrawal.TabIndex = 33
        Me.tidrawal.Text = "IDR"
        '
        'takhir
        '
        Me.takhir.AutoSize = True
        Me.takhir.Font = New System.Drawing.Font("Aqua Grotesque", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.takhir.Location = New System.Drawing.Point(385, 368)
        Me.takhir.Name = "takhir"
        Me.takhir.Size = New System.Drawing.Size(109, 61)
        Me.takhir.TabIndex = 34
        Me.takhir.Text = "IDR"
        '
        'Konversi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.takhir)
        Me.Controls.Add(Me.tidrawal)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.tduit2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.kursEUR2)
        Me.Controls.Add(Me.kursGBP2)
        Me.Controls.Add(Me.kursUSD2)
        Me.Controls.Add(Me.kursIDR2)
        Me.Controls.Add(Me.kursEUR)
        Me.Controls.Add(Me.kursGBP)
        Me.Controls.Add(Me.kursUSD)
        Me.Controls.Add(Me.kursIDR)
        Me.Controls.Add(Me.MaterialLabel8)
        Me.Controls.Add(Me.MaterialLabel7)
        Me.Controls.Add(Me.MaterialLabel6)
        Me.Controls.Add(Me.MaterialLabel5)
        Me.Controls.Add(Me.MaterialLabel4)
        Me.Controls.Add(Me.MaterialLabel3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.MaterialLabel2)
        Me.Controls.Add(Me.tjumlah)
        Me.Controls.Add(Me.MaterialLabel1)
        Me.Controls.Add(Me.MaterialFlatButton1)
        Me.Name = "Konversi"
        Me.Text = "Konversi Mata Uang"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MaterialFlatButton1 As MaterialSkin.Controls.MaterialFlatButton
    Friend WithEvents MaterialLabel1 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents MaterialRadioButton5 As MaterialSkin.Controls.MaterialRadioButton
    Friend WithEvents MaterialRadioButton6 As MaterialSkin.Controls.MaterialRadioButton
    Friend WithEvents MaterialRadioButton7 As MaterialSkin.Controls.MaterialRadioButton
    Friend WithEvents MaterialDivider2 As MaterialSkin.Controls.MaterialDivider
    Friend WithEvents MaterialRadioButton8 As MaterialSkin.Controls.MaterialRadioButton
    Friend WithEvents tjumlah As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents MaterialLabel2 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents MaterialLabel3 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents MaterialLabel4 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents MaterialLabel5 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents MaterialLabel6 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents MaterialLabel7 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents MaterialLabel8 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents kursIDR As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents kursUSD As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents kursGBP As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents kursEUR As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents kursEUR2 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents kursGBP2 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents kursUSD2 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents kursIDR2 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents tduit2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents tidrawal As Label
    Friend WithEvents takhir As Label
End Class
